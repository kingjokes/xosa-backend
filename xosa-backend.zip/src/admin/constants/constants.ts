export const jwtConstants = {
    secret: 'UsLMYR9v4RLLlQxTv01Ls2CM1RuWvVp58_VDcUI20dAOCDgPBEFFiL9aQUx_Wwx-4pL2j9fBaiXYG-2kyf73mLaIYn02xrVEGvFT7a9g8Gm_rPDukzSBKU1Yu2c-e2tF9tyMFbyixcowE0vaAU_TflDROlnCRw87PeKooPQ1BDA',
  };